<div>
    <!-- Header with Filters -->
    <div class="mb-6" 
        x-data="{
            filters: {
                startDate: '{{ $startDate }}',
                endDate: '{{ $endDate }}',
                userId: '{{ $userId }}',
                role: '{{ $role }}'
            },
            init() {
                this.$watch('filters.startDate', () => this.applyFilters());
                this.$watch('filters.endDate', () => this.applyFilters());
                this.$watch('filters.userId', () => this.applyFilters());
                this.$watch('filters.role', () => this.applyFilters());
            },
            applyFilters() {
                $wire.applyFilters(this.filters);
            }
        }">
        <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mb-6">
            <div>
                <h1 class="text-2xl font-bold text-gray-900">Staff Attendance</h1>
                <p class="text-sm text-gray-500 mt-1">Track login and logout times for staff</p>
            </div>
        </div>

        <!-- Filters -->
        <div class="bg-white rounded-xl shadow-sm p-4 mb-6">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Start Date</label>
                    <input type="date" x-model="filters.startDate"
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-transparent">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">End Date</label>
                    <input type="date" x-model="filters.endDate"
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-transparent">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Staff Member</label>
                    <select x-model="filters.userId"
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-transparent">
                        <option value="">All Staff</option>
                        @foreach($users as $user)
                            <option value="{{ $user->id }}">{{ $user->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1">Role</label>
                    <select x-model="filters.role"
                        class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-500 focus:border-transparent">
                        <option value="">All Roles</option>
                        <option value="cashier">Cashier</option>
                        <option value="attendant">Attendant</option>
                    </select>
                </div>
            </div>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div class="bg-gradient-to-br from-brand-500 to-brand-600 rounded-2xl p-4 text-white">
            <p class="text-brand-100 text-xs font-medium uppercase">Total Logins</p>
            <p class="text-2xl font-bold mt-1">{{ number_format($totalRecords) }}</p>
            <p class="text-brand-200 text-sm">in selected period</p>
        </div>
        <div class="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl p-4 text-white">
            <p class="text-blue-100 text-xs font-medium uppercase">Total Hours</p>
            <p class="text-2xl font-bold mt-1">{{ $totalHours }} hrs</p>
            <p class="text-blue-200 text-sm">worked in period</p>
        </div>
        <div class="bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl p-4 text-white">
            <p class="text-green-100 text-xs font-medium uppercase">Active Now</p>
            <p class="text-2xl font-bold mt-1">{{ $activeNow }}</p>
            <p class="text-green-200 text-sm">currently logged in</p>
        </div>
    </div>

    <!-- Attendance Table -->
    <div class="bg-white rounded-xl shadow-sm overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Staff</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Role</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Location</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Login Time</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Logout Time</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Duration</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    @forelse($attendanceRecords as $record)
                        <tr class="{{ is_null($record->logout_at) ? 'bg-green-50' : '' }}">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    <div class="flex-shrink-0 h-10 w-10 rounded-full bg-brand-100 flex items-center justify-center">
                                        <span class="text-brand-600 font-semibold">{{ substr($record->user->name ?? 'U', 0, 1) }}</span>
                                    </div>
                                    <div class="ml-3">
                                        <div class="text-sm font-medium text-gray-900">{{ $record->user->name ?? 'Unknown' }}</div>
                                        <div class="text-xs text-gray-500">{{ $record->ip_address }}</div>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <span class="px-2 py-1 text-xs font-semibold rounded-full 
                                    {{ $record->user->role === 'cashier' ? 'bg-purple-100 text-purple-800' : 'bg-blue-100 text-blue-800' }}">
                                    {{ ucfirst($record->user->role ?? 'Unknown') }}
                                </span>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {{ $record->user->location->name ?? 'N/A' }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-gray-900">{{ $record->login_at->format('M d, Y') }}</div>
                                <div class="text-sm text-gray-500">{{ $record->login_at->format('h:i A') }}</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                @if($record->logout_at)
                                    <div class="text-sm text-gray-900">{{ $record->logout_at->format('M d, Y') }}</div>
                                    <div class="text-sm text-gray-500">{{ $record->logout_at->format('h:i A') }}</div>
                                @else
                                    <span class="text-sm text-green-600 font-medium">Still Active</span>
                                @endif
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                @if($record->logout_at)
                                    <span class="text-sm font-medium text-gray-900">{{ $record->formatted_duration }}</span>
                                @else
                                    <span class="text-sm text-green-600">
                                        {{ now()->diff($record->login_at)->format('%H:%I') }} (ongoing)
                                    </span>
                                @endif
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                @if(is_null($record->logout_at))
                                    <span class="px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                                        🟢 Online
                                    </span>
                                @else
                                    <span class="px-2 py-1 text-xs font-semibold rounded-full bg-gray-100 text-gray-800">
                                        Completed
                                    </span>
                                @endif
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="7" class="px-6 py-12 text-center">
                                <svg class="w-12 h-12 text-gray-400 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"/>
                                </svg>
                                <p class="text-gray-500">No attendance records found for the selected filters</p>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <div class="px-6 py-4 border-t border-gray-200">
            {{ $attendanceRecords->links() }}
        </div>
    </div>
</div>
