<?php

namespace App\Livewire\Reports;

use App\Models\UserAttendance;
use App\Models\User;
use Livewire\Component;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\WithPagination;

#[Layout('components.layouts.app')]
#[Title('Staff Attendance')]
class AttendanceIndex extends Component
{
    use WithPagination;

    public $startDate;
    public $endDate;
    public $userId = '';
    public $role = '';

    public function mount()
    {
        $this->startDate = now()->startOfMonth()->format('Y-m-d');
        $this->endDate = now()->format('Y-m-d');
    }

    public function applyFilters($filters)
    {
        $this->startDate = $filters['startDate'];
        $this->endDate = $filters['endDate'];
        $this->userId = $filters['userId'];
        $this->role = $filters['role'];
        $this->resetPage();
    }

    public function render()
    {
        $attendanceRecords = UserAttendance::query()
            ->with('user.location')
            ->when($this->userId, fn($q) => $q->where('user_id', $this->userId))
            ->when($this->role, function ($q) {
                $q->whereHas('user', fn($sub) => $sub->where('role', $this->role));
            })
            ->whereBetween('login_at', [$this->startDate . ' 00:00:00', $this->endDate . ' 23:59:59'])
            ->latest('login_at')
            ->paginate(20);

        // Get users for filter dropdown
        $users = User::whereIn('role', ['cashier', 'attendant'])
            ->where('is_active', true)
            ->orderBy('name')
            ->get();

        // Calculate stats
        $totalRecords = UserAttendance::query()
            ->when($this->userId, fn($q) => $q->where('user_id', $this->userId))
            ->when($this->role, function ($q) {
                $q->whereHas('user', fn($sub) => $sub->where('role', $this->role));
            })
            ->whereBetween('login_at', [$this->startDate . ' 00:00:00', $this->endDate . ' 23:59:59'])
            ->count();

        $totalHours = UserAttendance::query()
            ->when($this->userId, fn($q) => $q->where('user_id', $this->userId))
            ->when($this->role, function ($q) {
                $q->whereHas('user', fn($sub) => $sub->where('role', $this->role));
            })
            ->whereBetween('login_at', [$this->startDate . ' 00:00:00', $this->endDate . ' 23:59:59'])
            ->whereNotNull('logout_at')
            ->get()
            ->sum(fn($a) => $a->duration / 60); // Convert minutes to hours

        $activeNow = UserAttendance::whereNull('logout_at')->count();

        return view('livewire.reports.attendance-index', [
            'attendanceRecords' => $attendanceRecords,
            'users' => $users,
            'totalRecords' => $totalRecords,
            'totalHours' => round($totalHours, 1),
            'activeNow' => $activeNow,
        ]);
    }
}
