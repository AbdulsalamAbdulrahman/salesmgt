<?php

namespace App\Livewire\Reports;

use App\Models\Sale;
use App\Models\Product;
use App\Models\SaleItem;
use App\Models\Location;
use App\Models\Expense;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Livewire\Component;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Illuminate\Support\Facades\DB;
use Symfony\Component\HttpFoundation\StreamedResponse;

#[Layout('components.layouts.app')]
#[Title('Reports')]
class ReportIndex extends Component
{
    public $reportType = 'sales';
    public $startDate;
    public $endDate;
    public $locationId = '';

    public function mount()
    {
        $this->startDate = now()->startOfMonth()->format('Y-m-d');
        $this->endDate = now()->format('Y-m-d');
    }

    public function applyFilters($filters)
    {
        $this->reportType = $filters['reportType'];
        $this->startDate = $filters['startDate'];
        $this->endDate = $filters['endDate'];
        $this->locationId = $filters['locationId'];
    }

    public function exportReport()
    {
        $data = match($this->reportType) {
            'sales' => $this->getSalesReport(),
            'products' => $this->getProductsReport(),
            'profit' => $this->getProfitReport(),
            'staff' => $this->getStaffSummaryReport(),
            default => collect(),
        };

        if ($data->isEmpty()) {
            session()->flash('message', 'No data to export for the selected filters.');
            return;
        }

        $filename = $this->reportType . '_report_' . $this->startDate . '_to_' . $this->endDate . '.csv';

        return response()->streamDownload(function () use ($data) {
            $handle = fopen('php://output', 'w');
            
            // Add BOM for Excel UTF-8 compatibility
            fprintf($handle, chr(0xEF).chr(0xBB).chr(0xBF));

            if ($this->reportType === 'sales') {
                // Sales Report Headers
                fputcsv($handle, ['Sale #', 'Date', 'Cashier', 'Attendant', 'Location', 'Payment Method', 'Items Count', 'Total (₦)']);
                
                foreach ($data as $sale) {
                    fputcsv($handle, [
                        $sale->sale_number,
                        $sale->created_at->format('Y-m-d H:i'),
                        $sale->user->name ?? 'N/A',
                        $sale->attendant->name ?? '-',
                        $sale->location->name ?? 'N/A',
                        $sale->payment_method,
                        $sale->items->count(),
                        number_format($sale->total, 2, '.', ''),
                    ]);
                }

                // Summary row
                fputcsv($handle, []);
                fputcsv($handle, ['SUMMARY']);
                fputcsv($handle, ['Total Sales', $data->count()]);
                fputcsv($handle, ['Total Revenue', number_format($data->sum('total'), 2, '.', '')]);
                fputcsv($handle, ['Cash Sales', number_format($data->where('payment_method', 'CASH')->sum('total'), 2, '.', '')]);
                fputcsv($handle, ['Card Sales', number_format($data->where('payment_method', 'CARD')->sum('total'), 2, '.', '')]);
                fputcsv($handle, ['Transfer Sales', number_format($data->where('payment_method', 'TRANSFER')->sum('total'), 2, '.', '')]);

            } elseif ($this->reportType === 'products') {
                // Products Report Headers
                fputcsv($handle, ['Rank', 'Product Name', 'SKU', 'Quantity Sold', 'Total Revenue (₦)']);
                
                foreach ($data as $index => $item) {
                    fputcsv($handle, [
                        $index + 1,
                        $item->product->name ?? 'Unknown',
                        $item->product->sku ?? 'N/A',
                        $item->total_quantity,
                        number_format($item->total_revenue, 2, '.', ''),
                    ]);
                }

                // Summary row
                fputcsv($handle, []);
                fputcsv($handle, ['SUMMARY']);
                fputcsv($handle, ['Total Products', $data->count()]);
                fputcsv($handle, ['Total Quantity Sold', $data->sum('total_quantity')]);
                fputcsv($handle, ['Total Revenue', number_format($data->sum('total_revenue'), 2, '.', '')]);

            } elseif ($this->reportType === 'profit') {
                // Profit Report Headers
                fputcsv($handle, ['Sale #', 'Date', 'Revenue (₦)', 'Cost (₦)', 'Profit (₦)', 'Margin (%)']);
                
                $totalRevenue = 0;
                $totalCost = 0;
                $totalProfit = 0;

                foreach ($data as $sale) {
                    $revenue = $sale->total;
                    $cost = $sale->items->sum(fn($item) => $item->cost_price * $item->quantity);
                    $profit = $revenue - $cost;
                    $margin = $revenue > 0 ? ($profit / $revenue) * 100 : 0;

                    $totalRevenue += $revenue;
                    $totalCost += $cost;
                    $totalProfit += $profit;

                    fputcsv($handle, [
                        $sale->sale_number,
                        $sale->created_at->format('Y-m-d'),
                        number_format($revenue, 2, '.', ''),
                        number_format($cost, 2, '.', ''),
                        number_format($profit, 2, '.', ''),
                        number_format($margin, 2, '.', ''),
                    ]);
                }

                // Summary row
                $overallMargin = $totalRevenue > 0 ? ($totalProfit / $totalRevenue) * 100 : 0;
                fputcsv($handle, []);
                fputcsv($handle, ['TOTALS', '', number_format($totalRevenue, 2, '.', ''), number_format($totalCost, 2, '.', ''), number_format($totalProfit, 2, '.', ''), number_format($overallMargin, 2, '.', '')]);
            
            } elseif ($this->reportType === 'staff') {
                // Staff Summary Report Headers
                fputcsv($handle, ['Staff Name', 'Role', 'Location', 'Sales Count', 'Total Sales (₦)', 'Total Expenses (₦)', 'Net Balance (₦)']);
                
                $grandTotalSales = 0;
                $grandTotalExpenses = 0;

                foreach ($data as $staff) {
                    $grandTotalSales += $staff->total_sales;
                    $grandTotalExpenses += $staff->total_expenses;

                    fputcsv($handle, [
                        $staff->name,
                        ucfirst($staff->role),
                        $staff->location->name ?? 'N/A',
                        $staff->sales_count,
                        number_format($staff->total_sales, 2, '.', ''),
                        number_format($staff->total_expenses, 2, '.', ''),
                        number_format($staff->total_sales - $staff->total_expenses, 2, '.', ''),
                    ]);
                }

                // Summary row
                fputcsv($handle, []);
                fputcsv($handle, ['TOTALS', '', '', $data->sum('sales_count'), number_format($grandTotalSales, 2, '.', ''), number_format($grandTotalExpenses, 2, '.', ''), number_format($grandTotalSales - $grandTotalExpenses, 2, '.', '')]);
            }

            fclose($handle);
        }, $filename, [
            'Content-Type' => 'text/csv; charset=UTF-8',
            'Content-Disposition' => 'attachment; filename="' . $filename . '"',
        ]);
    }

    public function render()
    {
        $data = [];

        if ($this->reportType === 'sales') {
            $data = $this->getSalesReport();
        } elseif ($this->reportType === 'products') {
            $data = $this->getProductsReport();
        } elseif ($this->reportType === 'profit') {
            $data = $this->getProfitReport();
        } elseif ($this->reportType === 'staff') {
            $data = $this->getStaffSummaryReport();
        }

        $locations = Location::where('is_active', true)->get();

        // Calculate expenses and closing balance for sales report
        $totalExpenses = 0;
        $closingBalance = 0;
        if ($this->reportType === 'sales') {
            $totalExpenses = Expense::query()
                ->when($this->locationId, fn($q) => $q->where('location_id', $this->locationId))
                ->whereBetween('expense_date', [$this->startDate, $this->endDate])
                ->sum('amount');
            $totalRevenue = collect($data)->sum('total');
            $closingBalance = $totalRevenue - $totalExpenses;
        }

        return view('livewire.reports.report-index', [
            'reportData' => $data,
            'locations' => $locations,
            'totalExpenses' => $totalExpenses,
            'closingBalance' => $closingBalance,
        ]);
    }

    protected function getSalesReport()
    {
        return Sale::query()
            ->with(['user', 'location', 'items'])
            ->when($this->locationId, fn($q) => $q->where('location_id', $this->locationId))
            ->whereBetween('created_at', [$this->startDate . ' 00:00:00', $this->endDate . ' 23:59:59'])
            ->latest()
            ->get();
    }

    protected function getProductsReport()
    {
        return SaleItem::query()
            ->join('sales', 'sale_items.sale_id', '=', 'sales.id')
            ->join('products', 'sale_items.product_id', '=', 'products.id')
            ->when($this->locationId, fn($q) => $q->where('sales.location_id', $this->locationId))
            ->whereBetween('sales.created_at', [$this->startDate . ' 00:00:00', $this->endDate . ' 23:59:59'])
            ->select('products.id as product_id', 'products.name', 'products.sku')
            ->selectRaw('SUM(sale_items.quantity) as total_quantity, SUM(sale_items.total) as total_revenue')
            ->groupBy('products.id', 'products.name', 'products.sku')
            ->orderByDesc('total_quantity')
            ->limit(20)
            ->get()
            ->map(function ($item) {
                $item->product = (object) ['name' => $item->name, 'sku' => $item->sku];
                return $item;
            });
    }

    protected function getProfitReport()
    {
        return Sale::query()
            ->with('items')
            ->when($this->locationId, fn($q) => $q->where('location_id', $this->locationId))
            ->whereBetween('created_at', [$this->startDate . ' 00:00:00', $this->endDate . ' 23:59:59'])
            ->latest()
            ->get();
    }

    protected function getStaffSummaryReport()
    {
        $users = User::query()
            ->with('location')
            ->when($this->locationId, fn($q) => $q->where('location_id', $this->locationId))
            ->whereIn('role', ['admin', 'cashier'])
            ->where('is_active', true)
            ->get();

        return $users->map(function ($user) {
            // Get sales totals for this user
            $salesQuery = Sale::where('user_id', $user->id)
                ->whereBetween('created_at', [$this->startDate . ' 00:00:00', $this->endDate . ' 23:59:59']);

            $user->sales_count = $salesQuery->count();
            $user->total_sales = (clone $salesQuery)->sum('total');

            // Get expenses totals for this user
            $user->total_expenses = Expense::where('user_id', $user->id)
                ->whereBetween('expense_date', [$this->startDate, $this->endDate])
                ->sum('amount');

            return $user;
        })->sortByDesc('total_sales')->values();
    }
}
