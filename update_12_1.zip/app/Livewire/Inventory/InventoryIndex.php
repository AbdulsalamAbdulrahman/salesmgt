<?php

namespace App\Livewire\Inventory;

use App\Models\Product;
use App\Models\Location;
use App\Models\InventoryStock;
use App\Models\InventoryMovement;
use Livewire\Component;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\WithPagination;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

#[Layout('components.layouts.app')]
#[Title('Inventory')]
class InventoryIndex extends Component
{
    use WithPagination;

    public $search = '';
    public $location_id = '';
    public $showModal = false;
    public $modalType = 'stock_in'; // stock_in, stock_out, adjustment
    public $selectedProduct = null;
    public $quantity = 0;
    public $notes = '';

    public function mount()
    {
        $user = Auth::user();
        $this->location_id = $user->location_id ?? Location::where('is_active', true)->first()?->id;
    }

    public function updatingSearch()
    {
        $this->resetPage();
    }

    public function applyFilters($filters)
    {
        $this->search = $filters['search'];
        $this->location_id = $filters['location_id'];
        $this->resetPage();
    }
    
    public function processMovementAlpine($type, $productId, $quantity, $notes)
    {
        $this->modalType = $type;
        $this->selectedProduct = Product::find($productId);
        $this->quantity = $quantity;
        $this->notes = $notes;
        $this->processMovement();
    }

    public function openModal($type, $productId)
    {
        $this->modalType = $type;
        $this->selectedProduct = Product::find($productId);
        $this->quantity = 0;
        $this->notes = '';
        $this->showModal = true;
    }

    public function processMovement()
    {
        $this->validate([
            'quantity' => 'required|numeric|min:1',
            'notes' => 'nullable|string|max:500',
        ]);

        // Cast to integer to handle leading zeros like "035"
        $this->quantity = (int) $this->quantity;

        if (!$this->selectedProduct || !$this->location_id) {
            session()->flash('error', 'Invalid product or location.');
            return;
        }

        DB::beginTransaction();
        try {
            $stock = InventoryStock::firstOrCreate(
                ['product_id' => $this->selectedProduct->id, 'location_id' => $this->location_id],
                ['quantity' => 0]
            );

            $quantityBefore = $stock->quantity;
            $type = strtoupper($this->modalType);

            switch ($this->modalType) {
                case 'stock_in':
                    $stock->increment('quantity', $this->quantity);
                    $type = 'IN';
                    break;
                case 'stock_out':
                    if ($stock->quantity < $this->quantity) {
                        session()->flash('error', 'Insufficient stock.');
                        return;
                    }
                    $stock->decrement('quantity', $this->quantity);
                    $type = 'OUT';
                    break;
                case 'adjustment':
                    $stock->quantity = $this->quantity;
                    $stock->save();
                    $type = 'ADJUSTMENT';
                    break;
            }

            InventoryMovement::create([
                'product_id' => $this->selectedProduct->id,
                'location_id' => $this->location_id,
                'user_id' => Auth::id(),
                'type' => $type,
                'quantity' => $this->modalType === 'adjustment' ? abs($stock->quantity - $quantityBefore) : $this->quantity,
                'quantity_before' => $quantityBefore,
                'quantity_after' => $stock->fresh()->quantity,
                'notes' => $this->notes,
                'reference' => 'INV-' . date('YmdHis'),
            ]);

            DB::commit();
            $this->showModal = false;
            session()->flash('message', 'Inventory updated successfully.');

        } catch (\Exception $e) {
            DB::rollback();
            session()->flash('error', 'Error: ' . $e->getMessage());
        }
    }

    public function render()
    {
        $products = Product::active()
            ->with(['inventoryStocks' => fn($q) => $q->where('location_id', $this->location_id)])
            ->when($this->search, function ($q) {
                $q->where('name', 'like', "%{$this->search}%")
                  ->orWhere('sku', 'like', "%{$this->search}%");
            })
            ->orderBy('name')
            ->paginate(15);

        $locations = Location::where('is_active', true)->get();

        return view('livewire.inventory.inventory-index', [
            'products' => $products,
            'locations' => $locations,
        ]);
    }
}
