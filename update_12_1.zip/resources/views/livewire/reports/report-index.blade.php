<div class="space-y-6">
    <!-- Header -->
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 p-6">
        <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div>
                <h2 class="text-2xl font-bold text-gray-800">Reports</h2>
                <p class="text-gray-500 text-sm mt-1">Analyze sales performance and inventory data</p>
            </div>
            <div class="flex flex-wrap items-center gap-3"
                x-data="{
                    filters: {
                        reportType: '{{ $reportType }}',
                        startDate: '{{ $startDate }}',
                        endDate: '{{ $endDate }}',
                        locationId: '{{ $locationId }}'
                    },
                    init() {
                        this.$watch('filters', () => this.applyFilters());
                    },
                    applyFilters() {
                        $wire.applyFilters(this.filters);
                    }
                }"
            >
                <!-- Report Type -->
                <select x-model="filters.reportType" 
                    class="px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-brand-500 bg-gray-50 font-medium">
                    <option value="sales">📊 Sales Report</option>
                    <option value="products">📦 Top Products</option>
                    <option value="profit">💰 Profit Report</option>
                </select>

                <!-- Date Range -->
                <div class="flex items-center gap-2">
                    <input type="date" x-model="filters.startDate" 
                        class="px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-brand-500 bg-gray-50">
                    <span class="text-gray-400">to</span>
                    <input type="date" x-model="filters.endDate" 
                        class="px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-brand-500 bg-gray-50">
                </div>

                <!-- Location Filter (Admin Only) -->
                @if(Auth::user()->isAdmin())
                <select x-model="filters.locationId" 
                    class="px-4 py-2.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-brand-500 focus:border-brand-500 bg-gray-50">
                    <option value="">All Locations</option>
                    @foreach($locations as $location)
                        <option value="{{ $location->id }}">{{ $location->name }}</option>
                    @endforeach
                </select>
                @endif

                <!-- Export -->
                <button wire:click="exportReport" 
                    class="px-4 py-2.5 bg-green-600 text-white rounded-xl hover:bg-green-700 transition-colors font-medium flex items-center gap-2">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                    </svg>
                    Export
                </button>
            </div>
        </div>
    </div>

    @if(session('message'))
        <div class="p-4 bg-brand-50 border border-brand-200 text-brand-600 rounded-xl flex items-center">
            <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clip-rule="evenodd"/></svg>
            {{ session('message') }}
        </div>
    @endif

    <!-- Summary Stats -->
    @if($reportType === 'sales')
    <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4">
        <div class="bg-gradient-to-br from-brand-400 to-brand-500 rounded-2xl p-5 text-white">
            <p class="text-brand-100 text-sm font-medium">Total Sales</p>
            <p class="text-3xl font-bold mt-1">{{ count($reportData) }}</p>
        </div>
        <div class="bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl p-5 text-white">
            <p class="text-green-100 text-sm font-medium">Total Revenue</p>
            <p class="text-2xl font-bold mt-1">₦{{ number_format(collect($reportData)->sum('total'), 0) }}</p>
        </div>
        <div class="bg-gradient-to-br from-amber-500 to-orange-600 rounded-2xl p-5 text-white">
            <p class="text-amber-100 text-sm font-medium">Cash Sales</p>
            <p class="text-2xl font-bold mt-1">₦{{ number_format(collect($reportData)->where('payment_method', 'CASH')->sum('total'), 0) }}</p>
        </div>
        <div class="bg-gradient-to-br from-brand-300 to-brand-500 rounded-2xl p-5 text-white">
            <p class="text-brand-100 text-sm font-medium">Card Sales</p>
            <p class="text-2xl font-bold mt-1">₦{{ number_format(collect($reportData)->where('payment_method', 'CARD')->sum('total'), 0) }}</p>
        </div>
        <div class="bg-gradient-to-br from-purple-500 to-violet-600 rounded-2xl p-5 text-white">
            <p class="text-purple-100 text-sm font-medium">Transfer Sales</p>
            <p class="text-2xl font-bold mt-1">₦{{ number_format(collect($reportData)->where('payment_method', 'TRANSFER')->sum('total'), 0) }}</p>
        </div>
        <div class="bg-gradient-to-br from-rose-500 to-red-600 rounded-2xl p-5 text-white">
            <p class="text-rose-100 text-sm font-medium">Total Expenses</p>
            <p class="text-2xl font-bold mt-1">₦{{ number_format($totalExpenses, 0) }}</p>
        </div>
        <div class="bg-gradient-to-br {{ $closingBalance >= 0 ? 'from-teal-500 to-cyan-600' : 'from-red-600 to-rose-700' }} rounded-2xl p-5 text-white">
            <p class="{{ $closingBalance >= 0 ? 'text-teal-100' : 'text-red-100' }} text-sm font-medium">Closing Balance</p>
            <p class="text-2xl font-bold mt-1">₦{{ number_format(abs($closingBalance), 0) }}</p>
            <p class="{{ $closingBalance >= 0 ? 'text-teal-200' : 'text-red-200' }} text-xs mt-1">{{ $closingBalance >= 0 ? 'Net Profit' : 'Net Loss' }}</p>
        </div>
    </div>
    @elseif($reportType === 'profit')
    @php
        $totalRevenue = 0;
        $totalCost = 0;
        $totalProfit = 0;
        foreach($reportData as $sale) {
            $revenue = $sale->total;
            $cost = $sale->items->sum(fn($item) => $item->cost_price * $item->quantity);
            $totalRevenue += $revenue;
            $totalCost += $cost;
            $totalProfit += ($revenue - $cost);
        }
        $overallMargin = $totalRevenue > 0 ? ($totalProfit / $totalRevenue) * 100 : 0;
    @endphp
    <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
        <div class="bg-gradient-to-br from-brand-400 to-brand-500 rounded-2xl p-5 text-white">
            <p class="text-brand-100 text-sm font-medium">Total Sales</p>
            <p class="text-3xl font-bold mt-1">{{ count($reportData) }}</p>
        </div>
        <div class="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl p-5 text-white">
            <p class="text-blue-100 text-sm font-medium">Total Revenue</p>
            <p class="text-2xl font-bold mt-1">₦{{ number_format($totalRevenue, 0) }}</p>
        </div>
        <div class="bg-gradient-to-br from-gray-500 to-gray-600 rounded-2xl p-5 text-white">
            <p class="text-gray-200 text-sm font-medium">Total Cost</p>
            <p class="text-2xl font-bold mt-1">₦{{ number_format($totalCost, 0) }}</p>
        </div>
        <div class="bg-gradient-to-br {{ $totalProfit >= 0 ? 'from-emerald-500 to-green-600' : 'from-red-500 to-rose-600' }} rounded-2xl p-5 text-white">
            <p class="{{ $totalProfit >= 0 ? 'text-green-100' : 'text-red-100' }} text-sm font-medium">Net Profit</p>
            <p class="text-2xl font-bold mt-1">₦{{ number_format($totalProfit, 0) }}</p>
        </div>
        <div class="bg-gradient-to-br from-emerald-500 to-green-600 rounded-2xl p-5 text-white">
            <p class="text-green-100 text-sm font-medium">Profit Margin</p>
            <p class="text-2xl font-bold mt-1">{{ number_format($overallMargin, 1) }}%</p>
        </div>
    </div>
    @endif

    <!-- Report Content -->
    <div class="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        @if($reportType === 'sales')
            <!-- Sales Report -->
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-gray-50 border-b border-gray-100">
                        <tr>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase">Sale #</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase">Date</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase">Cashier</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase">Attendant</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase">Location</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase">Payment</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase">Items</th>
                            <th class="px-6 py-4 text-right text-xs font-semibold text-gray-500 uppercase">Total</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        @forelse($reportData as $sale)
                            <tr class="hover:bg-gray-50">
                                <td class="px-6 py-4 font-mono font-semibold text-brand-500">{{ $sale->sale_number }}</td>
                                <td class="px-6 py-4 text-sm text-gray-600">{{ $sale->created_at->format('M d, Y H:i') }}</td>
                                <td class="px-6 py-4 text-sm text-gray-800">{{ $sale->user->name ?? 'N/A' }}</td>
                                <td class="px-6 py-4 text-sm text-gray-800">{{ $sale->attendant->name ?? '-' }}</td>
                                <td class="px-6 py-4 text-sm text-gray-600">{{ $sale->location->name ?? 'N/A' }}</td>
                                <td class="px-6 py-4">
                                    <span class="px-2.5 py-1 rounded-full text-xs font-semibold 
                                        @if($sale->payment_method === 'CASH') bg-amber-100 text-amber-700
                                        @elseif($sale->payment_method === 'CARD') bg-brand-100 text-brand-600
                                        @else bg-purple-100 text-purple-700
                                        @endif">
                                        {{ $sale->payment_method }}
                                    </span>
                                </td>
                                <td class="px-6 py-4 text-sm text-gray-600">
                                    <div>{{ $sale->items->sum('quantity') }} pcs</div>
                                    <div class="text-xs text-gray-400">{{ $sale->items->count() }} {{ Str::plural('product', $sale->items->count()) }}</div>
                                </td>
                                <td class="px-6 py-4 text-right font-bold text-gray-800">₦{{ number_format($sale->total, 0) }}</td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="8" class="px-6 py-16 text-center text-gray-500">
                                    <svg class="w-12 h-12 mx-auto mb-4 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                                    </svg>
                                    No sales data found for the selected period
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        @elseif($reportType === 'products')
            <!-- Top Products Report -->
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-gray-50 border-b border-gray-100">
                        <tr>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase">Rank</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase">Product</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase">SKU</th>
                            <th class="px-6 py-4 text-right text-xs font-semibold text-gray-500 uppercase">Qty Sold</th>
                            <th class="px-6 py-4 text-right text-xs font-semibold text-gray-500 uppercase">Revenue</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        @forelse($reportData as $index => $item)
                            <tr class="hover:bg-gray-50">
                                <td class="px-6 py-4">
                                    @if($index < 3)
                                        <span class="w-8 h-8 rounded-full flex items-center justify-center font-bold {{ $index === 0 ? 'bg-yellow-100 text-yellow-700' : ($index === 1 ? 'bg-gray-100 text-gray-700' : 'bg-orange-100 text-orange-700') }}">
                                            {{ $index + 1 }}
                                        </span>
                                    @else
                                        <span class="text-gray-500 pl-3">{{ $index + 1 }}</span>
                                    @endif
                                </td>
                                <td class="px-6 py-4 font-medium text-gray-800">{{ $item->product->name ?? 'Unknown' }}</td>
                                <td class="px-6 py-4 text-sm text-gray-500 font-mono">{{ $item->product->sku ?? 'N/A' }}</td>
                                <td class="px-6 py-4 text-right">
                                    <span class="px-3 py-1 bg-brand-100 text-brand-600 rounded-full font-semibold">{{ number_format($item->total_quantity) }}</span>
                                </td>
                                <td class="px-6 py-4 text-right font-bold text-green-600">₦{{ number_format($item->total_revenue, 0) }}</td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="5" class="px-6 py-16 text-center text-gray-500">
                                    <svg class="w-12 h-12 mx-auto mb-4 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/>
                                    </svg>
                                    No product sales data found
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        @elseif($reportType === 'profit')
            <!-- Profit Table -->
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-gray-50 border-b border-gray-100">
                        <tr>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase">Sale #</th>
                            <th class="px-6 py-4 text-left text-xs font-semibold text-gray-500 uppercase">Date</th>
                            <th class="px-6 py-4 text-right text-xs font-semibold text-gray-500 uppercase">Revenue</th>
                            <th class="px-6 py-4 text-right text-xs font-semibold text-gray-500 uppercase">Cost</th>
                            <th class="px-6 py-4 text-right text-xs font-semibold text-gray-500 uppercase">Profit</th>
                            <th class="px-6 py-4 text-right text-xs font-semibold text-gray-500 uppercase">Margin</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100">
                        @forelse($reportData as $sale)
                            @php
                                $revenue = $sale->total;
                                $cost = $sale->items->sum(fn($item) => $item->cost_price * $item->quantity);
                                $profit = $revenue - $cost;
                                $margin = $revenue > 0 ? ($profit / $revenue) * 100 : 0;
                            @endphp
                            <tr class="hover:bg-gray-50">
                                <td class="px-6 py-4 font-mono font-semibold text-brand-500">{{ $sale->sale_number }}</td>
                                <td class="px-6 py-4 text-sm text-gray-600">{{ $sale->created_at->format('M d, Y') }}</td>
                                <td class="px-6 py-4 text-right text-gray-800">₦{{ number_format($revenue, 0) }}</td>
                                <td class="px-6 py-4 text-right text-gray-500">₦{{ number_format($cost, 0) }}</td>
                                <td class="px-6 py-4 text-right font-semibold {{ $profit >= 0 ? 'text-green-600' : 'text-red-600' }}">
                                    ₦{{ number_format($profit, 0) }}
                                </td>
                                <td class="px-6 py-4 text-right">
                                    <span class="px-2.5 py-1 rounded-full text-xs font-semibold bg-green-100 text-green-700">
                                        {{ number_format($margin, 1) }}%
                                    </span>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6" class="px-6 py-16 text-center text-gray-500">
                                    <svg class="w-12 h-12 mx-auto mb-4 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>
                                    </svg>
                                    No profit data found
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        @endif
    </div>
</div>
