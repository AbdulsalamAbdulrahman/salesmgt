<?php

namespace App\Livewire;

use Livewire\Component;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use App\Models\Sale;
use App\Models\Product;
use App\Models\InventoryStock;
use Illuminate\Support\Facades\Auth;

#[Layout('components.layouts.app')]
#[Title('Dashboard')]
class Dashboard extends Component
{
    public function render()
    {
        $user = Auth::user();
        $isAdmin = $user->role === 'admin';
        $locationId = $user->location_id;

        // Today's sales
        $todaySales = Sale::when(!$isAdmin, function ($query) {
                return $query->where('user_id', Auth::id());
            })
            ->whereDate('created_at', today())
            ->sum('total');

        $todaySalesCount = Sale::when(!$isAdmin, function ($query) {
                return $query->where('user_id', Auth::id());
            })
            ->whereDate('created_at', today())
            ->count();

        // This month's sales
        $monthSales = Sale::when(!$isAdmin, function ($query) {
                return $query->where('user_id', Auth::id());
            })
            ->whereMonth('created_at', now()->month)
            ->whereYear('created_at', now()->year)
            ->sum('total');

        // Low stock products
        $lowStockProducts = Product::active()
            ->whereHas('inventoryStocks', function ($q) use ($locationId, $isAdmin) {
                if (!$isAdmin) {
                    $q->where('location_id', $locationId);
                }
            })
            ->get()
            ->filter(function ($product) use ($locationId, $isAdmin) {
                $stock = $isAdmin ? $product->total_stock : $product->getStockAtLocation($locationId);
                return $stock <= $product->low_stock_threshold;
            })
            ->count();

        // Total products
        $totalProducts = Product::active()->count();

        // Recent sales
        $recentSales = Sale::with(['user', 'location', 'items.product'])
            ->when(!$isAdmin, function ($query) {
                return $query->where('user_id', Auth::id());
            })
            ->latest('created_at')
            ->take(10)
            ->get();

        return view('livewire.dashboard', [
            'todaySales' => $todaySales,
            'todaySalesCount' => $todaySalesCount,
            'monthSales' => $monthSales,
            'lowStockProducts' => $lowStockProducts,
            'totalProducts' => $totalProducts,
            'recentSales' => $recentSales,
            'isAdmin' => $isAdmin,
        ]);
    }
}
